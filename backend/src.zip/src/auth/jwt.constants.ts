export const jwtConstants = {
    secret: 'secretsecretsecretsecretsecretsecret'
}