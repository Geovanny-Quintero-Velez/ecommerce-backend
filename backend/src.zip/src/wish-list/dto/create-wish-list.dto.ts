export class CreateWishListDto {}
