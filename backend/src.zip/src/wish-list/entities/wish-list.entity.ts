export class WishList {}
