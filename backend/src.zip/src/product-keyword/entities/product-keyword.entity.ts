export class ProductKeyword {}
