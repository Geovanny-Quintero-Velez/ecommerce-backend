export class CreateProductKeywordDto {}
